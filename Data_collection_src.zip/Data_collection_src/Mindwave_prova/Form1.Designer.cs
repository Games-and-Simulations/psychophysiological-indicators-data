﻿namespace Mindwave_prova
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea12 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend12 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series18 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series19 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea13 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend13 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series20 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series21 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea14 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend14 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series22 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series23 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea15 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend15 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series24 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series25 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea16 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend16 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series26 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series27 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea17 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend17 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series28 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series29 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea18 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend18 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series30 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea19 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend19 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series31 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea20 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend20 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series32 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea21 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend21 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series33 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea22 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend22 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series34 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button_connect = new System.Windows.Forms.Button();
            this.textBox_info = new System.Windows.Forms.TextBox();
            this.progressBar_att = new System.Windows.Forms.ProgressBar();
            this.label_att = new System.Windows.Forms.Label();
            this.label_med = new System.Windows.Forms.Label();
            this.progressBar_med = new System.Windows.Forms.ProgressBar();
            this.panel_eeg = new System.Windows.Forms.Panel();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.chart11 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label29 = new System.Windows.Forms.Label();
            this.datebox2 = new System.Windows.Forms.TextBox();
            this.button14 = new System.Windows.Forms.Button();
            this.chart10 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button13 = new System.Windows.Forms.Button();
            this.chart9 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button12 = new System.Windows.Forms.Button();
            this.chart8 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button11 = new System.Windows.Forms.Button();
            this.chart7 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button9 = new System.Windows.Forms.Button();
            this.chart6 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button8 = new System.Windows.Forms.Button();
            this.chart5 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button6 = new System.Windows.Forms.Button();
            this.chart4 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label27 = new System.Windows.Forms.Label();
            this.datebox1 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.time2box = new System.Windows.Forms.TextBox();
            this.time1box = new System.Windows.Forms.TextBox();
            this.chart3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.parse_gsr = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.labelGsr = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textBoxSkill = new System.Windows.Forms.TextBox();
            this.textBoxAge = new System.Windows.Forms.TextBox();
            this.textBoxGender = new System.Windows.Forms.TextBox();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox_porte2 = new System.Windows.Forms.ComboBox();
            this.button_stop = new System.Windows.Forms.Button();
            this.button_save = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox_gamma2 = new System.Windows.Forms.TextBox();
            this.textBox_poor = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_beta2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_alpha2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox_theta = new System.Windows.Forms.TextBox();
            this.textBox_delta = new System.Windows.Forms.TextBox();
            this.textBox_gamma1 = new System.Windows.Forms.TextBox();
            this.textBox_beta1 = new System.Windows.Forms.TextBox();
            this.textBox_alpha1 = new System.Windows.Forms.TextBox();
            this.textBox_raw = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.testdbDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.testdbDataSet = new Mindwave_prova.testdbDataSet();
            this.panel_ecg = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox_resp = new System.Windows.Forms.TextBox();
            this.textBox_posture = new System.Windows.Forms.TextBox();
            this.textBox_hr = new System.Windows.Forms.TextBox();
            this.textBox_ecg = new System.Windows.Forms.TextBox();
            this.button_save_bh3 = new System.Windows.Forms.Button();
            this.comboBox_porte = new System.Windows.Forms.ComboBox();
            this.button_open = new System.Windows.Forms.Button();
            this.button_mw = new System.Windows.Forms.Button();
            this.label_mw_con = new System.Windows.Forms.Label();
            this.label_mw_save = new System.Windows.Forms.Label();
            this.textBox_filename = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label_noname = new System.Windows.Forms.Label();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.panel_eeg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.testdbDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.testdbDataSet)).BeginInit();
            this.panel_ecg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button_connect
            // 
            this.button_connect.Location = new System.Drawing.Point(18, 54);
            this.button_connect.Name = "button_connect";
            this.button_connect.Size = new System.Drawing.Size(113, 28);
            this.button_connect.TabIndex = 5;
            this.button_connect.Text = "OPEN";
            this.button_connect.UseVisualStyleBackColor = true;
            this.button_connect.Click += new System.EventHandler(this.button_connect_Click);
            // 
            // textBox_info
            // 
            this.textBox_info.Location = new System.Drawing.Point(18, 145);
            this.textBox_info.Multiline = true;
            this.textBox_info.Name = "textBox_info";
            this.textBox_info.Size = new System.Drawing.Size(113, 81);
            this.textBox_info.TabIndex = 5;
            // 
            // progressBar_att
            // 
            this.progressBar_att.Location = new System.Drawing.Point(223, 12);
            this.progressBar_att.Name = "progressBar_att";
            this.progressBar_att.Size = new System.Drawing.Size(100, 23);
            this.progressBar_att.TabIndex = 5;
            // 
            // label_att
            // 
            this.label_att.AutoSize = true;
            this.label_att.Location = new System.Drawing.Point(148, 22);
            this.label_att.Name = "label_att";
            this.label_att.Size = new System.Drawing.Size(69, 13);
            this.label_att.TabIndex = 3;
            this.label_att.Text = "ATTENTION";
            // 
            // label_med
            // 
            this.label_med.AutoSize = true;
            this.label_med.Location = new System.Drawing.Point(143, 51);
            this.label_med.Name = "label_med";
            this.label_med.Size = new System.Drawing.Size(74, 13);
            this.label_med.TabIndex = 5;
            this.label_med.Text = "MEDITATION";
            // 
            // progressBar_med
            // 
            this.progressBar_med.Location = new System.Drawing.Point(223, 41);
            this.progressBar_med.Name = "progressBar_med";
            this.progressBar_med.Size = new System.Drawing.Size(100, 23);
            this.progressBar_med.TabIndex = 4;
            // 
            // panel_eeg
            // 
            this.panel_eeg.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel_eeg.Controls.Add(this.button18);
            this.panel_eeg.Controls.Add(this.button17);
            this.panel_eeg.Controls.Add(this.button16);
            this.panel_eeg.Controls.Add(this.chart11);
            this.panel_eeg.Controls.Add(this.label29);
            this.panel_eeg.Controls.Add(this.datebox2);
            this.panel_eeg.Controls.Add(this.button14);
            this.panel_eeg.Controls.Add(this.chart10);
            this.panel_eeg.Controls.Add(this.button13);
            this.panel_eeg.Controls.Add(this.chart9);
            this.panel_eeg.Controls.Add(this.button12);
            this.panel_eeg.Controls.Add(this.chart8);
            this.panel_eeg.Controls.Add(this.button11);
            this.panel_eeg.Controls.Add(this.chart7);
            this.panel_eeg.Controls.Add(this.button9);
            this.panel_eeg.Controls.Add(this.chart6);
            this.panel_eeg.Controls.Add(this.button8);
            this.panel_eeg.Controls.Add(this.chart5);
            this.panel_eeg.Controls.Add(this.button6);
            this.panel_eeg.Controls.Add(this.chart4);
            this.panel_eeg.Controls.Add(this.label27);
            this.panel_eeg.Controls.Add(this.datebox1);
            this.panel_eeg.Controls.Add(this.label25);
            this.panel_eeg.Controls.Add(this.label24);
            this.panel_eeg.Controls.Add(this.time2box);
            this.panel_eeg.Controls.Add(this.time1box);
            this.panel_eeg.Controls.Add(this.chart3);
            this.panel_eeg.Controls.Add(this.chart2);
            this.panel_eeg.Controls.Add(this.button4);
            this.panel_eeg.Controls.Add(this.button3);
            this.panel_eeg.Controls.Add(this.button2);
            this.panel_eeg.Controls.Add(this.chart1);
            this.panel_eeg.Controls.Add(this.parse_gsr);
            this.panel_eeg.Controls.Add(this.label22);
            this.panel_eeg.Controls.Add(this.labelGsr);
            this.panel_eeg.Controls.Add(this.label20);
            this.panel_eeg.Controls.Add(this.label19);
            this.panel_eeg.Controls.Add(this.label18);
            this.panel_eeg.Controls.Add(this.label17);
            this.panel_eeg.Controls.Add(this.textBoxSkill);
            this.panel_eeg.Controls.Add(this.textBoxAge);
            this.panel_eeg.Controls.Add(this.textBoxGender);
            this.panel_eeg.Controls.Add(this.textBoxName);
            this.panel_eeg.Controls.Add(this.button1);
            this.panel_eeg.Controls.Add(this.comboBox_porte2);
            this.panel_eeg.Controls.Add(this.button_stop);
            this.panel_eeg.Controls.Add(this.button_save);
            this.panel_eeg.Controls.Add(this.label11);
            this.panel_eeg.Controls.Add(this.textBox_gamma2);
            this.panel_eeg.Controls.Add(this.textBox_poor);
            this.panel_eeg.Controls.Add(this.label10);
            this.panel_eeg.Controls.Add(this.textBox_beta2);
            this.panel_eeg.Controls.Add(this.label9);
            this.panel_eeg.Controls.Add(this.textBox_alpha2);
            this.panel_eeg.Controls.Add(this.label8);
            this.panel_eeg.Controls.Add(this.textBox_theta);
            this.panel_eeg.Controls.Add(this.textBox_delta);
            this.panel_eeg.Controls.Add(this.textBox_gamma1);
            this.panel_eeg.Controls.Add(this.textBox_beta1);
            this.panel_eeg.Controls.Add(this.textBox_alpha1);
            this.panel_eeg.Controls.Add(this.textBox_raw);
            this.panel_eeg.Controls.Add(this.label7);
            this.panel_eeg.Controls.Add(this.label6);
            this.panel_eeg.Controls.Add(this.label5);
            this.panel_eeg.Controls.Add(this.label4);
            this.panel_eeg.Controls.Add(this.label3);
            this.panel_eeg.Controls.Add(this.label1);
            this.panel_eeg.Controls.Add(this.label2);
            this.panel_eeg.Controls.Add(this.progressBar2);
            this.panel_eeg.Controls.Add(this.label_att);
            this.panel_eeg.Controls.Add(this.button_connect);
            this.panel_eeg.Controls.Add(this.label_med);
            this.panel_eeg.Controls.Add(this.textBox_info);
            this.panel_eeg.Controls.Add(this.progressBar_med);
            this.panel_eeg.Controls.Add(this.progressBar_att);
            this.panel_eeg.Location = new System.Drawing.Point(198, 14);
            this.panel_eeg.Name = "panel_eeg";
            this.panel_eeg.Size = new System.Drawing.Size(1064, 616);
            this.panel_eeg.TabIndex = 7;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(966, 12);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(88, 49);
            this.button18.TabIndex = 86;
            this.button18.Text = "Set last experiment\'s date and time";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(540, 98);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(132, 28);
            this.button17.TabIndex = 85;
            this.button17.Text = "SET SUBJECT INFO";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(340, 415);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(171, 23);
            this.button16.TabIndex = 84;
            this.button16.Text = "Show Fun";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Visible = false;
            // 
            // chart11
            // 
            chartArea12.Name = "ChartArea1";
            this.chart11.ChartAreas.Add(chartArea12);
            legend12.Enabled = false;
            legend12.Name = "Legend1";
            this.chart11.Legends.Add(legend12);
            this.chart11.Location = new System.Drawing.Point(3, 444);
            this.chart11.Name = "chart11";
            series18.ChartArea = "ChartArea1";
            series18.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series18.Legend = "Legend1";
            series18.Name = "Series1";
            series19.ChartArea = "ChartArea1";
            series19.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series19.Legend = "Legend1";
            series19.Name = "Series2";
            this.chart11.Series.Add(series18);
            this.chart11.Series.Add(series19);
            this.chart11.Size = new System.Drawing.Size(508, 169);
            this.chart11.TabIndex = 83;
            this.chart11.Text = "chart11";
            this.chart11.Visible = false;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(705, 37);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(53, 13);
            this.label29.TabIndex = 82;
            this.label29.Text = "End date:";
            // 
            // datebox2
            // 
            this.datebox2.Location = new System.Drawing.Point(830, 38);
            this.datebox2.Name = "datebox2";
            this.datebox2.Size = new System.Drawing.Size(100, 20);
            this.datebox2.TabIndex = 1;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(532, 211);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(171, 23);
            this.button14.TabIndex = 80;
            this.button14.Text = "Show Breathing Rate Amp Data";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Visible = false;
            this.button14.Click += new System.EventHandler(this.draw_bramp_chart);
            // 
            // chart10
            // 
            chartArea13.Name = "ChartArea1";
            this.chart10.ChartAreas.Add(chartArea13);
            legend13.Enabled = false;
            legend13.Name = "Legend1";
            this.chart10.Legends.Add(legend13);
            this.chart10.Location = new System.Drawing.Point(354, 240);
            this.chart10.Name = "chart10";
            series20.ChartArea = "ChartArea1";
            series20.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series20.Legend = "Legend1";
            series20.Name = "Series1";
            series21.ChartArea = "ChartArea1";
            series21.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series21.Legend = "Legend1";
            series21.Name = "Series2";
            this.chart10.Series.Add(series20);
            this.chart10.Series.Add(series21);
            this.chart10.Size = new System.Drawing.Size(347, 169);
            this.chart10.TabIndex = 79;
            this.chart10.Text = "chart10";
            this.chart10.Visible = false;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(201, 211);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(149, 23);
            this.button13.TabIndex = 78;
            this.button13.Text = "Show Breathing Rate Data";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Visible = false;
            this.button13.Click += new System.EventHandler(this.draw_br_chart);
            // 
            // chart9
            // 
            chartArea14.Name = "ChartArea1";
            this.chart9.ChartAreas.Add(chartArea14);
            legend14.Enabled = false;
            legend14.Name = "Legend1";
            this.chart9.Legends.Add(legend14);
            this.chart9.Location = new System.Drawing.Point(-16, 234);
            this.chart9.Name = "chart9";
            series22.ChartArea = "ChartArea1";
            series22.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series22.Legend = "Legend1";
            series22.Name = "Series1";
            series23.ChartArea = "ChartArea1";
            series23.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series23.Legend = "Legend1";
            series23.Name = "Series2";
            this.chart9.Series.Add(series22);
            this.chart9.Series.Add(series23);
            this.chart9.Size = new System.Drawing.Size(347, 169);
            this.chart9.TabIndex = 77;
            this.chart9.Text = "chart9";
            this.chart9.Visible = false;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(886, 415);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(168, 23);
            this.button12.TabIndex = 76;
            this.button12.Text = "Show Activity Data";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Visible = false;
            this.button12.Click += new System.EventHandler(this.draw_activity_chart);
            // 
            // chart8
            // 
            chartArea15.Name = "ChartArea1";
            this.chart8.ChartAreas.Add(chartArea15);
            legend15.Enabled = false;
            legend15.Name = "Legend1";
            this.chart8.Legends.Add(legend15);
            this.chart8.Location = new System.Drawing.Point(707, 444);
            this.chart8.Name = "chart8";
            series24.ChartArea = "ChartArea1";
            series24.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series24.Legend = "Legend1";
            series24.Name = "Series1";
            series25.ChartArea = "ChartArea1";
            series25.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series25.Legend = "Legend1";
            series25.Name = "Series2";
            this.chart8.Series.Add(series24);
            this.chart8.Series.Add(series25);
            this.chart8.Size = new System.Drawing.Size(347, 169);
            this.chart8.TabIndex = 75;
            this.chart8.Text = "chart8";
            this.chart8.Visible = false;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(559, 415);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(144, 23);
            this.button11.TabIndex = 74;
            this.button11.Text = "Show HR Amplitude Data";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Visible = false;
            this.button11.Click += new System.EventHandler(this.draw_hramp_chart);
            // 
            // chart7
            // 
            chartArea16.Name = "ChartArea1";
            this.chart7.ChartAreas.Add(chartArea16);
            legend16.Enabled = false;
            legend16.Name = "Legend1";
            this.chart7.Legends.Add(legend16);
            this.chart7.Location = new System.Drawing.Point(356, 444);
            this.chart7.Name = "chart7";
            series26.ChartArea = "ChartArea1";
            series26.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series26.Legend = "Legend1";
            series26.Name = "Series1";
            series27.ChartArea = "ChartArea1";
            series27.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series27.Legend = "Legend1";
            series27.Name = "Series2";
            this.chart7.Series.Add(series26);
            this.chart7.Series.Add(series27);
            this.chart7.Size = new System.Drawing.Size(347, 169);
            this.chart7.TabIndex = 73;
            this.chart7.Text = "chart7";
            this.chart7.Visible = false;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(201, 415);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(149, 23);
            this.button9.TabIndex = 72;
            this.button9.Text = "Show Heart Rate Data";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Visible = false;
            this.button9.Click += new System.EventHandler(this.draw_hr_chart);
            // 
            // chart6
            // 
            chartArea17.Name = "ChartArea1";
            this.chart6.ChartAreas.Add(chartArea17);
            legend17.Enabled = false;
            legend17.Name = "Legend1";
            this.chart6.Legends.Add(legend17);
            this.chart6.Location = new System.Drawing.Point(3, 444);
            this.chart6.Name = "chart6";
            series28.ChartArea = "ChartArea1";
            series28.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series28.Legend = "Legend1";
            series28.Name = "Series1";
            series29.ChartArea = "ChartArea1";
            series29.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series29.Legend = "Legend1";
            series29.Name = "Series2";
            this.chart6.Series.Add(series28);
            this.chart6.Series.Add(series29);
            this.chart6.Size = new System.Drawing.Size(347, 169);
            this.chart6.TabIndex = 71;
            this.chart6.Text = "chart6";
            this.chart6.Visible = false;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(516, 383);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(187, 23);
            this.button8.TabIndex = 70;
            this.button8.Text = "Show GSR Resistance Data";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Visible = false;
            this.button8.Click += new System.EventHandler(this.draw_gsr_resistance_chart);
            // 
            // chart5
            // 
            chartArea18.Name = "ChartArea1";
            this.chart5.ChartAreas.Add(chartArea18);
            legend18.Enabled = false;
            legend18.Name = "Legend1";
            this.chart5.Legends.Add(legend18);
            this.chart5.Location = new System.Drawing.Point(354, 409);
            this.chart5.Name = "chart5";
            series30.ChartArea = "ChartArea1";
            series30.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series30.Legend = "Legend1";
            series30.Name = "Series1";
            this.chart5.Series.Add(series30);
            this.chart5.Size = new System.Drawing.Size(347, 201);
            this.chart5.TabIndex = 69;
            this.chart5.Text = "chart5";
            this.chart5.Visible = false;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(163, 383);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(187, 23);
            this.button6.TabIndex = 68;
            this.button6.Text = "Show GSR Conductance Data";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Visible = false;
            this.button6.Click += new System.EventHandler(this.draw_gsr_conductance_chart);
            // 
            // chart4
            // 
            chartArea19.Name = "ChartArea1";
            this.chart4.ChartAreas.Add(chartArea19);
            legend19.Enabled = false;
            legend19.Name = "Legend1";
            this.chart4.Legends.Add(legend19);
            this.chart4.Location = new System.Drawing.Point(1, 409);
            this.chart4.Name = "chart4";
            series31.ChartArea = "ChartArea1";
            series31.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series31.Legend = "Legend1";
            series31.Name = "Series1";
            this.chart4.Series.Add(series31);
            this.chart4.Size = new System.Drawing.Size(347, 201);
            this.chart4.TabIndex = 67;
            this.chart4.Text = "chart4";
            this.chart4.Visible = false;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(705, 15);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(119, 13);
            this.label27.TabIndex = 65;
            this.label27.Text = "Start date (yyyy-mm-dd):";
            // 
            // datebox1
            // 
            this.datebox1.Location = new System.Drawing.Point(830, 12);
            this.datebox1.Name = "datebox1";
            this.datebox1.Size = new System.Drawing.Size(100, 20);
            this.datebox1.TabIndex = 0;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(705, 89);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(51, 13);
            this.label25.TabIndex = 62;
            this.label25.Text = "End time:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(705, 64);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(54, 13);
            this.label24.TabIndex = 61;
            this.label24.Text = "Start time:";
            // 
            // time2box
            // 
            this.time2box.Location = new System.Drawing.Point(830, 89);
            this.time2box.Name = "time2box";
            this.time2box.Size = new System.Drawing.Size(100, 20);
            this.time2box.TabIndex = 3;
            // 
            // time1box
            // 
            this.time1box.Location = new System.Drawing.Point(830, 63);
            this.time1box.Name = "time1box";
            this.time1box.Size = new System.Drawing.Size(100, 20);
            this.time1box.TabIndex = 2;
            // 
            // chart3
            // 
            chartArea20.Name = "ChartArea1";
            this.chart3.ChartAreas.Add(chartArea20);
            legend20.Enabled = false;
            legend20.Name = "Legend1";
            this.chart3.Legends.Add(legend20);
            this.chart3.Location = new System.Drawing.Point(709, 412);
            this.chart3.Name = "chart3";
            series32.ChartArea = "ChartArea1";
            series32.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series32.Legend = "Legend1";
            series32.Name = "Series1";
            this.chart3.Series.Add(series32);
            this.chart3.Size = new System.Drawing.Size(347, 201);
            this.chart3.TabIndex = 56;
            this.chart3.Text = "chart3";
            this.chart3.Visible = false;
            // 
            // chart2
            // 
            chartArea21.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea21);
            legend21.Enabled = false;
            legend21.Name = "Legend1";
            this.chart2.Legends.Add(legend21);
            this.chart2.Location = new System.Drawing.Point(356, 412);
            this.chart2.Name = "chart2";
            series33.ChartArea = "ChartArea1";
            series33.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series33.Legend = "Legend1";
            series33.Name = "Series1";
            this.chart2.Series.Add(series33);
            this.chart2.Size = new System.Drawing.Size(347, 201);
            this.chart2.TabIndex = 55;
            this.chart2.Text = "chart2";
            this.chart2.Visible = false;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(900, 383);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(156, 23);
            this.button4.TabIndex = 54;
            this.button4.Text = "Show Blinking Frequency";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Visible = false;
            this.button4.Click += new System.EventHandler(this.draw_blink_frequency_chart);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(524, 383);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(179, 23);
            this.button3.TabIndex = 53;
            this.button3.Text = "Show Meditation Data";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.draw_meditation_chart);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(208, 383);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(142, 23);
            this.button2.TabIndex = 50;
            this.button2.Text = "Show Attention Data";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.draw_attention_chart);
            // 
            // chart1
            // 
            chartArea22.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea22);
            legend22.Enabled = false;
            legend22.Name = "Legend1";
            this.chart1.Legends.Add(legend22);
            this.chart1.Location = new System.Drawing.Point(3, 412);
            this.chart1.Name = "chart1";
            series34.ChartArea = "ChartArea1";
            series34.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series34.Legend = "Legend1";
            series34.Name = "Series1";
            this.chart1.Series.Add(series34);
            this.chart1.Size = new System.Drawing.Size(347, 201);
            this.chart1.TabIndex = 39;
            this.chart1.Text = "chart1";
            this.chart1.Visible = false;
            // 
            // parse_gsr
            // 
            this.parse_gsr.Location = new System.Drawing.Point(540, 163);
            this.parse_gsr.Name = "parse_gsr";
            this.parse_gsr.Size = new System.Drawing.Size(132, 28);
            this.parse_gsr.TabIndex = 49;
            this.parse_gsr.Text = "PARSE GSR LOG";
            this.parse_gsr.UseVisualStyleBackColor = true;
            this.parse_gsr.Click += new System.EventHandler(this.parse_gsr_log);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(152, 178);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(55, 13);
            this.label22.TabIndex = 48;
            this.label22.Text = "Gsr value:";
            // 
            // labelGsr
            // 
            this.labelGsr.AutoSize = true;
            this.labelGsr.Location = new System.Drawing.Point(213, 178);
            this.labelGsr.Name = "labelGsr";
            this.labelGsr.Size = new System.Drawing.Size(23, 13);
            this.labelGsr.TabIndex = 47;
            this.labelGsr.Text = "null";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(512, 75);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(54, 13);
            this.label20.TabIndex = 46;
            this.label20.Text = "Skill level:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(537, 49);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 13);
            this.label19.TabIndex = 45;
            this.label19.Text = "Age:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(521, 27);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(45, 13);
            this.label18.TabIndex = 44;
            this.label18.Text = "Gender:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(491, 7);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(75, 13);
            this.label17.TabIndex = 43;
            this.label17.Text = "Subject name:";
            // 
            // textBoxSkill
            // 
            this.textBoxSkill.Location = new System.Drawing.Point(572, 72);
            this.textBoxSkill.Name = "textBoxSkill";
            this.textBoxSkill.Size = new System.Drawing.Size(100, 20);
            this.textBoxSkill.TabIndex = 42;
            // 
            // textBoxAge
            // 
            this.textBoxAge.Location = new System.Drawing.Point(572, 49);
            this.textBoxAge.Name = "textBoxAge";
            this.textBoxAge.Size = new System.Drawing.Size(100, 20);
            this.textBoxAge.TabIndex = 41;
            // 
            // textBoxGender
            // 
            this.textBoxGender.Location = new System.Drawing.Point(572, 27);
            this.textBoxGender.Name = "textBoxGender";
            this.textBoxGender.Size = new System.Drawing.Size(100, 20);
            this.textBoxGender.TabIndex = 40;
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(572, 4);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(100, 20);
            this.textBoxName.TabIndex = 39;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(540, 129);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(132, 28);
            this.button1.TabIndex = 38;
            this.button1.Text = "PARSE BH LOG";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.parse_bioharness_log);
            // 
            // comboBox_porte2
            // 
            this.comboBox_porte2.FormattingEnabled = true;
            this.comboBox_porte2.Location = new System.Drawing.Point(18, 23);
            this.comboBox_porte2.Name = "comboBox_porte2";
            this.comboBox_porte2.Size = new System.Drawing.Size(121, 21);
            this.comboBox_porte2.TabIndex = 37;
            // 
            // button_stop
            // 
            this.button_stop.Location = new System.Drawing.Point(18, 116);
            this.button_stop.Name = "button_stop";
            this.button_stop.Size = new System.Drawing.Size(113, 23);
            this.button_stop.TabIndex = 36;
            this.button_stop.Text = "STOP";
            this.button_stop.UseVisualStyleBackColor = true;
            this.button_stop.Click += new System.EventHandler(this.button_STOP_Click);
            // 
            // button_save
            // 
            this.button_save.Location = new System.Drawing.Point(18, 88);
            this.button_save.Name = "button_save";
            this.button_save.Size = new System.Drawing.Size(113, 23);
            this.button_save.TabIndex = 35;
            this.button_save.Text = "SAVE DATA";
            this.button_save.UseVisualStyleBackColor = true;
            this.button_save.Click += new System.EventHandler(this.button_save_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(148, 145);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(70, 13);
            this.label11.TabIndex = 34;
            this.label11.Text = "POOR DATA";
            // 
            // textBox_gamma2
            // 
            this.textBox_gamma2.Location = new System.Drawing.Point(385, 125);
            this.textBox_gamma2.Name = "textBox_gamma2";
            this.textBox_gamma2.Size = new System.Drawing.Size(100, 20);
            this.textBox_gamma2.TabIndex = 33;
            // 
            // textBox_poor
            // 
            this.textBox_poor.Location = new System.Drawing.Point(223, 141);
            this.textBox_poor.Name = "textBox_poor";
            this.textBox_poor.Size = new System.Drawing.Size(100, 20);
            this.textBox_poor.TabIndex = 32;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(332, 129);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 13);
            this.label10.TabIndex = 31;
            this.label10.Text = "GAMMA2";
            // 
            // textBox_beta2
            // 
            this.textBox_beta2.Location = new System.Drawing.Point(385, 79);
            this.textBox_beta2.Name = "textBox_beta2";
            this.textBox_beta2.Size = new System.Drawing.Size(100, 20);
            this.textBox_beta2.TabIndex = 30;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(344, 83);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 13);
            this.label9.TabIndex = 29;
            this.label9.Text = "BETA2";
            // 
            // textBox_alpha2
            // 
            this.textBox_alpha2.Location = new System.Drawing.Point(385, 34);
            this.textBox_alpha2.Name = "textBox_alpha2";
            this.textBox_alpha2.Size = new System.Drawing.Size(100, 20);
            this.textBox_alpha2.TabIndex = 28;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(337, 37);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 13);
            this.label8.TabIndex = 27;
            this.label8.Text = "ALPHA2";
            // 
            // textBox_theta
            // 
            this.textBox_theta.Location = new System.Drawing.Point(385, 171);
            this.textBox_theta.Name = "textBox_theta";
            this.textBox_theta.Size = new System.Drawing.Size(100, 20);
            this.textBox_theta.TabIndex = 26;
            // 
            // textBox_delta
            // 
            this.textBox_delta.Location = new System.Drawing.Point(385, 148);
            this.textBox_delta.Name = "textBox_delta";
            this.textBox_delta.Size = new System.Drawing.Size(100, 20);
            this.textBox_delta.TabIndex = 25;
            // 
            // textBox_gamma1
            // 
            this.textBox_gamma1.Location = new System.Drawing.Point(385, 102);
            this.textBox_gamma1.Name = "textBox_gamma1";
            this.textBox_gamma1.Size = new System.Drawing.Size(100, 20);
            this.textBox_gamma1.TabIndex = 24;
            // 
            // textBox_beta1
            // 
            this.textBox_beta1.Location = new System.Drawing.Point(385, 56);
            this.textBox_beta1.Name = "textBox_beta1";
            this.textBox_beta1.Size = new System.Drawing.Size(100, 20);
            this.textBox_beta1.TabIndex = 23;
            // 
            // textBox_alpha1
            // 
            this.textBox_alpha1.Location = new System.Drawing.Point(385, 12);
            this.textBox_alpha1.Name = "textBox_alpha1";
            this.textBox_alpha1.Size = new System.Drawing.Size(100, 20);
            this.textBox_alpha1.TabIndex = 22;
            // 
            // textBox_raw
            // 
            this.textBox_raw.Location = new System.Drawing.Point(223, 115);
            this.textBox_raw.Name = "textBox_raw";
            this.textBox_raw.Size = new System.Drawing.Size(100, 20);
            this.textBox_raw.TabIndex = 21;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(152, 118);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "RAW DATA";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(341, 175);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "THETA";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(342, 152);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "DELTA";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(334, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "GAMMA1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(344, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "BETA1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(160, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "BLINKING";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(337, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "ALPHA1";
            // 
            // progressBar2
            // 
            this.progressBar2.Location = new System.Drawing.Point(223, 70);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(100, 23);
            this.progressBar2.TabIndex = 7;
            // 
            // testdbDataSetBindingSource
            // 
            this.testdbDataSetBindingSource.DataSource = this.testdbDataSet;
            this.testdbDataSetBindingSource.Position = 0;
            // 
            // testdbDataSet
            // 
            this.testdbDataSet.DataSetName = "testdbDataSet";
            this.testdbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel_ecg
            // 
            this.panel_ecg.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel_ecg.Controls.Add(this.label16);
            this.panel_ecg.Controls.Add(this.label15);
            this.panel_ecg.Controls.Add(this.label14);
            this.panel_ecg.Controls.Add(this.label13);
            this.panel_ecg.Controls.Add(this.textBox_resp);
            this.panel_ecg.Controls.Add(this.textBox_posture);
            this.panel_ecg.Controls.Add(this.textBox_hr);
            this.panel_ecg.Controls.Add(this.textBox_ecg);
            this.panel_ecg.Controls.Add(this.button_save_bh3);
            this.panel_ecg.Controls.Add(this.comboBox_porte);
            this.panel_ecg.Controls.Add(this.button_open);
            this.panel_ecg.Location = new System.Drawing.Point(196, 15);
            this.panel_ecg.Name = "panel_ecg";
            this.panel_ecg.Size = new System.Drawing.Size(674, 397);
            this.panel_ecg.TabIndex = 37;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(293, 334);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(116, 13);
            this.label16.TabIndex = 12;
            this.label16.Text = "RESPIRATORY RATE";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(320, 308);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(59, 13);
            this.label15.TabIndex = 11;
            this.label15.Text = "POSTURE";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(339, 282);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(23, 13);
            this.label14.TabIndex = 10;
            this.label14.Text = "HR";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(302, 256);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(90, 13);
            this.label13.TabIndex = 9;
            this.label13.Text = "ECG_RAWDATA";
            // 
            // textBox_resp
            // 
            this.textBox_resp.Location = new System.Drawing.Point(418, 331);
            this.textBox_resp.Name = "textBox_resp";
            this.textBox_resp.Size = new System.Drawing.Size(100, 20);
            this.textBox_resp.TabIndex = 8;
            // 
            // textBox_posture
            // 
            this.textBox_posture.Location = new System.Drawing.Point(418, 305);
            this.textBox_posture.Name = "textBox_posture";
            this.textBox_posture.Size = new System.Drawing.Size(100, 20);
            this.textBox_posture.TabIndex = 7;
            // 
            // textBox_hr
            // 
            this.textBox_hr.Location = new System.Drawing.Point(418, 279);
            this.textBox_hr.Name = "textBox_hr";
            this.textBox_hr.Size = new System.Drawing.Size(100, 20);
            this.textBox_hr.TabIndex = 6;
            // 
            // textBox_ecg
            // 
            this.textBox_ecg.Location = new System.Drawing.Point(418, 253);
            this.textBox_ecg.Name = "textBox_ecg";
            this.textBox_ecg.Size = new System.Drawing.Size(100, 20);
            this.textBox_ecg.TabIndex = 5;
            // 
            // button_save_bh3
            // 
            this.button_save_bh3.Location = new System.Drawing.Point(0, 0);
            this.button_save_bh3.Name = "button_save_bh3";
            this.button_save_bh3.Size = new System.Drawing.Size(75, 23);
            this.button_save_bh3.TabIndex = 14;
            // 
            // comboBox_porte
            // 
            this.comboBox_porte.Location = new System.Drawing.Point(0, 0);
            this.comboBox_porte.Name = "comboBox_porte";
            this.comboBox_porte.Size = new System.Drawing.Size(121, 21);
            this.comboBox_porte.TabIndex = 15;
            // 
            // button_open
            // 
            this.button_open.Location = new System.Drawing.Point(0, 0);
            this.button_open.Name = "button_open";
            this.button_open.Size = new System.Drawing.Size(75, 23);
            this.button_open.TabIndex = 16;
            // 
            // button_mw
            // 
            this.button_mw.BackColor = System.Drawing.Color.White;
            this.button_mw.Location = new System.Drawing.Point(32, 68);
            this.button_mw.Name = "button_mw";
            this.button_mw.Size = new System.Drawing.Size(139, 68);
            this.button_mw.TabIndex = 8;
            this.button_mw.Text = "MINDWAVE";
            this.button_mw.UseVisualStyleBackColor = false;
            this.button_mw.Click += new System.EventHandler(this.button_mw_Click);
            // 
            // label_mw_con
            // 
            this.label_mw_con.AutoSize = true;
            this.label_mw_con.ForeColor = System.Drawing.Color.Green;
            this.label_mw_con.Location = new System.Drawing.Point(35, 138);
            this.label_mw_con.Name = "label_mw_con";
            this.label_mw_con.Size = new System.Drawing.Size(97, 13);
            this.label_mw_con.TabIndex = 12;
            this.label_mw_con.Text = "MW CONNECTED";
            // 
            // label_mw_save
            // 
            this.label_mw_save.AutoSize = true;
            this.label_mw_save.ForeColor = System.Drawing.Color.Navy;
            this.label_mw_save.Location = new System.Drawing.Point(35, 153);
            this.label_mw_save.Name = "label_mw_save";
            this.label_mw_save.Size = new System.Drawing.Size(102, 13);
            this.label_mw_save.TabIndex = 13;
            this.label_mw_save.Text = "SAVING MW DATA";
            // 
            // textBox_filename
            // 
            this.textBox_filename.Location = new System.Drawing.Point(82, 13);
            this.textBox_filename.Name = "textBox_filename";
            this.textBox_filename.Size = new System.Drawing.Size(108, 20);
            this.textBox_filename.TabIndex = 19;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(10, 16);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 13);
            this.label12.TabIndex = 20;
            this.label12.Text = "FILE_NAME";
            // 
            // label_noname
            // 
            this.label_noname.AutoSize = true;
            this.label_noname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label_noname.Location = new System.Drawing.Point(63, 36);
            this.label_noname.Name = "label_noname";
            this.label_noname.Size = new System.Drawing.Size(86, 13);
            this.label_noname.TabIndex = 21;
            this.label_noname.Text = "Write a file name";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(198, 96);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(677, 213);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 38;
            this.pictureBox1.TabStop = false;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(32, 271);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(139, 23);
            this.button5.TabIndex = 67;
            this.button5.Text = "Show Mindwave Data";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.show_mindwave_charts);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(32, 300);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(139, 23);
            this.button7.TabIndex = 68;
            this.button7.Text = "Show GSR Data";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.show_gst_charts);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(32, 329);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(139, 23);
            this.button10.TabIndex = 69;
            this.button10.Text = "Show Bioharness Data";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.show_bioharness_charts);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1266, 633);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.label_noname);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.textBox_filename);
            this.Controls.Add(this.label_mw_save);
            this.Controls.Add(this.label_mw_con);
            this.Controls.Add(this.button_mw);
            this.Controls.Add(this.panel_eeg);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel_ecg);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel_eeg.ResumeLayout(false);
            this.panel_eeg.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.testdbDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.testdbDataSet)).EndInit();
            this.panel_ecg.ResumeLayout(false);
            this.panel_ecg.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_connect;
        private System.Windows.Forms.TextBox textBox_info;
        private System.Windows.Forms.ProgressBar progressBar_att;
        private System.Windows.Forms.Label label_att;
        private System.Windows.Forms.Label label_med;
        private System.Windows.Forms.ProgressBar progressBar_med;
        private System.Windows.Forms.Panel panel_eeg;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_raw;
        private System.Windows.Forms.TextBox textBox_theta;
        private System.Windows.Forms.TextBox textBox_delta;
        private System.Windows.Forms.TextBox textBox_gamma1;
        private System.Windows.Forms.TextBox textBox_beta1;
        private System.Windows.Forms.TextBox textBox_alpha1;
        private System.Windows.Forms.TextBox textBox_alpha2;
        private System.Windows.Forms.TextBox textBox_beta2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox_gamma2;
        private System.Windows.Forms.TextBox textBox_poor;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button_save;
        private System.Windows.Forms.Button button_stop;
        private System.Windows.Forms.Button button_mw;
        private System.Windows.Forms.Label label_mw_con;
        private System.Windows.Forms.Label label_mw_save;
        private System.Windows.Forms.TextBox textBox_filename;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label_noname;
        private System.Windows.Forms.Panel panel_ecg;
        private System.Windows.Forms.ComboBox comboBox_porte;
        private System.Windows.Forms.Button button_open;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button button_save_bh3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox_resp;
        private System.Windows.Forms.TextBox textBox_posture;
        private System.Windows.Forms.TextBox textBox_hr;
        private System.Windows.Forms.TextBox textBox_ecg;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox comboBox_porte2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBoxSkill;
        private System.Windows.Forms.TextBox textBoxAge;
        private System.Windows.Forms.TextBox textBoxGender;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.Button parse_gsr;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label labelGsr;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.BindingSource testdbDataSetBindingSource;
        private testdbDataSet testdbDataSet;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox datebox1;
        private System.Windows.Forms.TextBox time2box;
        private System.Windows.Forms.TextBox time1box;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart4;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart5;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart6;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart7;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart8;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart10;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart9;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox datebox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart11;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
    }
}

