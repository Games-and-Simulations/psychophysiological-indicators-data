﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using NeuroSky.ThinkGear;
using NeuroSky.ThinkGear.Algorithms;
//using System.Windows.Forms.DataVisualization.Charting;
using System.IO;
using System.IO.Ports;
using MySql.Data.MySqlClient;
using System.Diagnostics;

namespace Mindwave_prova
{
    public partial class Form1 : Form
    {
        string[] porte = SerialPort.GetPortNames();
        string path_relativo = Environment.CurrentDirectory;

        public Form1()
        {
            InitializeComponent();
            //pictureBox_blink.Visible = false;
            progressBar_att.Style = ProgressBarStyle.Blocks;
            //LoadGraph_eeg();
            label_mw_save.Visible = false;
            
            label_mw_con.Visible = false;
            label_noname.Visible = false;
            panel_ecg.Visible = false;
            panel_eeg.Visible = false;
        }

        string directory = Environment.CurrentDirectory + "/TEST/";
        string fase = "1_";

        //Mindeave
        int indice = 0;
        bool save_data = false;
        bool second = false;
        int r = 0; 
        string poor;
        string meditation;
        string attention;
        int blinkCounter = 0;
        bool blinkHolder = false;
        DateTime start = DateTime.Now;
        string[] raw = new string[26];
        string alfa1;
        string alfa2;
        string beta1;
        string beta2;
        string gamma1;
        string gamma2;
        string theta;
        string delta;
        string[] time_raw = new string[26];
        double[] eeg_grafico = new double[50];
        static Connector connector = new Connector();
        static HeartRateAcceleration heartRateAcceleration;
        static HeartRateRecovery heartRateRecovery;

        

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (string porta in porte)
                comboBox_porte.Items.Add(porta);
            foreach (string porta in porte)
                comboBox_porte2.Items.Add(porta);
            
        }



        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////MINDWAVE DEMO SAMPLE FUNCTIONS START HERE//////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        private void button_connect_Click(object sender, EventArgs e)
        {
            
                
            textBox_info.Text = "Hello EEG!";
            
           //// Initialize a new Connector and add event handlers
            connector = new Connector();
            connector.DeviceConnected += new EventHandler(OnDeviceConnected);
            connector.DeviceConnectFail += new EventHandler(OnDeviceFail);
            connector.DeviceValidating += new EventHandler(OnDeviceValidating);
            

            heartRateRecovery = new HeartRateRecovery();
            heartRateAcceleration = new HeartRateAcceleration();

            // Scan for devices
            connector.ConnectScan(comboBox_porte2.SelectedItem.ToString());



            connector.blinkDetectionEnabled = true;
        }

        public delegate void UpdateLabel();
        private void UpdateLabel_mw_con()
        {
            label_mw_con.Visible = true;
        }
        private void UpdateLabel_mw_save()
        {
            label_mw_save.Visible = true;
        }
        private void UpdateLabel_vis()
        {
            label_mw_save.Visible = true;
 //           label_shi_save.Visible = true;
        }
        private void UpdateLabel_novis()
        {
            label_mw_save.Visible = false;
   //         label_shi_save.Visible = false;
        }
        public delegate void UpdateTextBoxGen(string Dato1, string Dato2, string Dato3);
        private void UpdateTextGen(string DatoHR, string DatoP, string DatoR)
        {
            textBox_hr.Text = DatoHR;
            //move the caret to the end of the text
            textBox_posture.Text = DatoP;
            //scroll to the caret
            textBox_resp.Text = DatoR;
        }
        public delegate void UpdateTextBoxSP(string DatoTrasmesso);
        private void UpdateText(string Dato)
        {
            textBox_info.AppendText(Dato);
            //move the caret to the end of the text
            textBox_info.SelectionStart = textBox_info.TextLength;
            //scroll to the caret
            textBox_info.ScrollToCaret();
        }
        private void UpdateTextEcg(string Dato)
        {
            textBox_ecg.Text = Dato;
        }
        private void UpdateTextAlpha1(string Dato)
        {
            textBox_alpha1.Text = Dato;
        }
        private void UpdateTextAlpha2(string Dato)
        {
            textBox_alpha2.Text = Dato;
        }
        private void UpdateTextBeta1(string Dato)
        {
            textBox_beta1.Text = Dato;
        }
        private void UpdateTextBeta2(string Dato)
        {
            textBox_beta2.Text = Dato;
        }
        private void UpdateTextGamma1(string Dato)
        {
            textBox_gamma1.Text = Dato;
        }
        private void UpdateTextGamma2(string Dato)
        {
            textBox_gamma2.Text = Dato;
        }
        private void UpdateTextTheta(string Dato)
        {
            textBox_theta.Text = Dato;
        }
        private void UpdateTextDelta(string Dato)
        {
            textBox_delta.Text = Dato;
        }
        private void UpdateTextPoor(string Dato)
        {
            textBox_poor.Text = Dato;
        }

        public delegate void UpdateChartSP_eegtxt(double DatoTrasmesso);
        private void UpdateChart_eegtxt(double Dato)
        {
            textBox_raw.Text = Dato.ToString();
        }

        public delegate void UpdateChartSP_eeg(double[] DatoTrasmesso);
        private void UpdateChart_eeg(double[] Dato)
        {
            textBox_raw.Text = Dato.ToString();
             
        }



        public delegate void UpdatePictureBoxSP();
        private void UpdatePicture()
        {
           // pictureBox_blink.Visible = true;
        }

        public delegate void UpdateBarSP(string NumeroTrasmesso);
        private void UpdateBarAtt(string Numero)
        {
            progressBar_att.Value = Convert.ToInt32(Numero);
        }
        private void UpdateBarMed(string Numero1)
        {
            progressBar_med.Value = Convert.ToInt32(Numero1);
        }

        public void OnDeviceConnected(object sender, EventArgs e)
        {
            Connector.DeviceEventArgs de = (Connector.DeviceEventArgs)e;

            //Console.WriteLine("Device found on: " + de.Device.PortName);
            //textBox_info.AppendText("Device found on: " + de.Device.PortName);
            textBox_info.Invoke(new UpdateTextBoxSP(this.UpdateText), "Device found on: " + de.Device.PortName);
            label_mw_con.Invoke(new UpdateLabel(this.UpdateLabel_mw_con));
            de.Device.DataReceived += new EventHandler(OnDataReceived);
        }

        public void OnDeviceFail(object sender, EventArgs e)
        {
            //Console.WriteLine("No devices found! :(");
            //textBox_info.AppendText("No devices found! :(");
            textBox_info.Invoke(new UpdateTextBoxSP(this.UpdateText), "No devices found! :(");
        }

        public void OnDeviceValidating(object sender, EventArgs e)
        {
            //Console.WriteLine("Validating: ");
            //textBox_info.AppendText("Validating: ");
            heartRateRecovery.enableHeartRateRecovery();

            textBox_info.Invoke(new UpdateTextBoxSP(this.UpdateText), "Validating: ");
        }


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////MINDWAVE DEMO SAMPLE FUNCTIONS END HERE////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        //reset blink counter at the end of each minute
        public void resetBlinkCounter()
        {
            DateTime now = DateTime.Now;
            
            if ((now.Minute > start.Minute) || (now.Hour > start.Hour))
            {
                blinkCounter = 0;
                start = now;
                Console.WriteLine("blink counter reset");
            }

        }

        DateTime startTime = DateTime.UtcNow;

        //tgparser, update every time when mindwave data are received
        public void OnDataReceived(object sender, EventArgs e)
        {
                        
            Device.DataEventArgs de = (Device.DataEventArgs)e;
            NeuroSky.ThinkGear.DataRow[] tempDataRowArray = de.DataRowArray;

            TGParser tgParser = new TGParser();
            tgParser.Read(de.DataRowArray);

            connector.blinkDetectionEnabled = true;

            // build connection string
            string connectionString = "Server=localhost; Port=3306; Database=testdb; Uid=root; password=password;";
            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlCommand command = connection.CreateCommand();

            var test_name = "mrrrglg";
            connection.Open();
           
            /* Loop through new parsed data */
            for (int i = 0; i < tgParser.ParsedData.Length; i++)
            {
                resetBlinkCounter();
                if (tgParser.ParsedData[i].ContainsKey("Raw"))
                {
                    if ((tgParser.ParsedData[i]["Raw"] < -150)) {
                        if (DateTime.UtcNow - startTime > TimeSpan.FromSeconds(1))
                        {
                            
                            startTime = DateTime.UtcNow;
                            if (blinkHolder == false)
                                blinkCounter++;
                            blinkHolder = true;
                            /* var startTime = DateTime.UtcNow;
                             while (DateTime.UtcNow - startTime < TimeSpan.FromSeconds(1))
                             {
                                 // blink detection

                             }*/
                            Console.WriteLine("blink: " + blinkCounter.ToString());

                        }
                    }
                    if ((tgParser.ParsedData[i]["Raw"] > 0))
                    {
                        blinkHolder = false;
                    }

                        indice++;
                    eeg_grafico[indice] = tgParser.ParsedData[i]["Raw"];
                    Invoke(new UpdateChartSP_eegtxt(this.UpdateChart_eegtxt), tgParser.ParsedData[i]["Raw"]);
                    if (indice == 49)
                    {
                        //chart_eeg.Invoke(new UpdateChartSP_eeg(this.UpdateChart_eeg), eeg_grafico);
                        indice = 0;
                    }

                    if(save_data == true)
                    {
                        r++;                         
                    }
                        //Console.WriteLine("Raw Value:" + tgParser.ParsedData[i]["Raw"]);
                        raw[r] = tgParser.ParsedData[i]["Raw"].ToString();
                        time_raw[r] = DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalMilliseconds.ToString(); 
                }

                if (tgParser.ParsedData[i].ContainsKey("PoorSignal"))
                {
                    second = true;
                    //Console.WriteLine("Time:" + tgParser.ParsedData[i]["Time"]);
                    //Console.WriteLine("PQ Value:" + tgParser.ParsedData[i]["PoorSignal"]);
                    Invoke(new UpdateTextBoxSP(this.UpdateTextPoor), tgParser.ParsedData[i]["PoorSignal"].ToString());
                    poor = tgParser.ParsedData[i]["PoorSignal"].ToString();

                    ////this is required because heart rate value is not returned when you have poor signal 200
                    //if (poorSig != 200)
                    //{
                    //    int recovery = heartRateRecovery.getHeartRateRecovery(0, poorSig);
                    //    double[] acceleration = heartRateAcceleration.getAcceleration(0, poorSig);
                    //}

                }

                

                if (tgParser.ParsedData[i].ContainsKey("Attention"))
                {
                    //Console.WriteLine("Att Value:" + tgParser.ParsedData[i]["Attention"]);
                    attention = tgParser.ParsedData[i]["Attention"].ToString();
                    //attention_double = tgParser.ParsedData[i]["Attention"];
                    //textBox_info.Invoke(new UpdateTextBoxSP(this.UpdateText), "Att Value:" + tgParser.ParsedData[i]["Attention"]);
                    progressBar_att.Invoke(new UpdateBarSP(this.UpdateBarAtt), tgParser.ParsedData[i]["Attention"].ToString());
                    //textBox_info.AppendText("Att Value:" + tgParser.ParsedData[i]["Attention"]);
                }

                if (tgParser.ParsedData[i].ContainsKey("Meditation"))
                {
                    //Console.WriteLine("Med Value:" + tgParser.ParsedData[i]["Meditation"]);
                    //textBox_info.AppendText("Med Value:" + tgParser.ParsedData[i]["Meditation"]);
                    meditation = tgParser.ParsedData[i]["Meditation"].ToString();
                    //meditation_double = tgParser.ParsedData[i]["Meditation"];
                    //textBox_info.Invoke(new UpdateTextBoxSP(this.UpdateText), "Med Value:" + tgParser.ParsedData[i]["Meditation"]);
                    progressBar_med.Invoke(new UpdateBarSP(this.UpdateBarMed), tgParser.ParsedData[i]["Meditation"].ToString());
                }

                if (tgParser.ParsedData[i].ContainsKey("EnergyLevel"))
                {
                    //Console.WriteLine("Energy: " + tgParser.ParsedData[i]["EnergyLevel"]);
                }
                

                if (tgParser.ParsedData[i].ContainsKey("EegPowerAlpha1"))
                {
                    //Console.WriteLine("Heart Age: " + tgParser.ParsedData[i]["HeartAge"]);
                    alfa1 = tgParser.ParsedData[i]["EegPowerAlpha1"].ToString();
                    Invoke(new UpdateTextBoxSP(this.UpdateTextAlpha1), tgParser.ParsedData[i]["EegPowerAlpha1"].ToString());
                }
                if (tgParser.ParsedData[i].ContainsKey("EegPowerAlpha2"))
                {
                    //Console.WriteLine("Heart Age: " + tgParser.ParsedData[i]["HeartAge"]);
                    alfa2 = tgParser.ParsedData[i]["EegPowerAlpha2"].ToString();
                    Invoke(new UpdateTextBoxSP(this.UpdateTextAlpha2), tgParser.ParsedData[i]["EegPowerAlpha2"].ToString());
                }
                if (tgParser.ParsedData[i].ContainsKey("EegPowerBeta1"))
                {
                    //Console.WriteLine("Heart Age: " + tgParser.ParsedData[i]["HeartAge"]);
                    beta1 = tgParser.ParsedData[i]["EegPowerBeta1"].ToString();
                    Invoke(new UpdateTextBoxSP(this.UpdateTextBeta1), tgParser.ParsedData[i]["EegPowerBeta1"].ToString());
                }
                if (tgParser.ParsedData[i].ContainsKey("EegPowerBeta2"))
                {
                    //Console.WriteLine("Heart Age: " + tgParser.ParsedData[i]["HeartAge"]);
                    beta2 = tgParser.ParsedData[i]["EegPowerBeta2"].ToString();
                    Invoke(new UpdateTextBoxSP(this.UpdateTextBeta2), tgParser.ParsedData[i]["EegPowerBeta2"].ToString());
                }
                if (tgParser.ParsedData[i].ContainsKey("EegPowerGamma1"))
                {
                    //Console.WriteLine("Heart Age: " + tgParser.ParsedData[i]["HeartAge"]);
                    gamma1 = tgParser.ParsedData[i]["EegPowerGamma1"].ToString();
                    Invoke(new UpdateTextBoxSP(this.UpdateTextGamma1), tgParser.ParsedData[i]["EegPowerGamma1"].ToString());
                }
                if (tgParser.ParsedData[i].ContainsKey("EegPowerGamma2"))
                {
                    //Console.WriteLine("Heart Age: " + tgParser.ParsedData[i]["HeartAge"]);
                    gamma2 = tgParser.ParsedData[i]["EegPowerGamma2"].ToString();
                    Invoke(new UpdateTextBoxSP(this.UpdateTextGamma2), tgParser.ParsedData[i]["EegPowerGamma2"].ToString());
                }
                if (tgParser.ParsedData[i].ContainsKey("EegPowerDelta"))
                {
                    //Console.WriteLine("Heart Age: " + tgParser.ParsedData[i]["HeartAge"]);
                    delta = tgParser.ParsedData[i]["EegPowerDelta"].ToString();
                    Invoke(new UpdateTextBoxSP(this.UpdateTextDelta), tgParser.ParsedData[i]["EegPowerDelta"].ToString());
                }

                if (tgParser.ParsedData[i].ContainsKey("EegPowerTheta"))
                {
                    //Console.WriteLine("Heart Age: " + tgParser.ParsedData[i]["HeartAge"]);
                    theta = tgParser.ParsedData[i]["EegPowerTheta"].ToString();
                    Invoke(new UpdateTextBoxSP(this.UpdateTextTheta), tgParser.ParsedData[i]["EegPowerTheta"].ToString());

                }

                if (r == 25 && save_data == true)
                {
                    StreamWriter file3 = new StreamWriter(directory + textBox_filename.Text + "_" + fase + "_EEG" + ".txt", true);
                    for (int h = 1; h <= r; h++)
                    {
                        file3.WriteLine(raw[h] + "," + time_raw[h]);
                    }
                    file3.Close();
                    r = 0;
                }
                
                if (save_data == true && second == true)
                {
                    
                    
                    // insert data into local database
                    command.CommandText = "INSERT INTO testdb.test (subject_name, timedate, mindwave_attention, mindwave_meditation, mindwave_blink_frequency) values (@test_name, @time, @attention, @meditation, @mindwave_blink_frequency)";

                    // name 
                    command.Parameters.AddWithValue("@test_name", test_name);
                    // current time
                    command.Parameters.AddWithValue("@time", DateTime.Now.ToString("yyyy-MM-dd HH':'mm':'ss"));
                    // attention
                    command.Parameters.AddWithValue("@attention", attention);
                    // meditation
                    command.Parameters.AddWithValue("@meditation", meditation);
                    // blink frequency
                    command.Parameters.AddWithValue("@mindwave_blink_frequency", blinkCounter);
                    
                    command.ExecuteNonQuery();
                    
                    

                    
                    StreamWriter file4 = new StreamWriter(directory + textBox_filename.Text + "_" + fase + "_WAVES" + ".txt", true);
                    // write into txt, format for database
                    file4.WriteLine(attention + "," + meditation + "," + DateTime.UtcNow.ToString("yyyy-MM-dd HH':'mm':'ss"));

                    file4.Close();
                    second = false;
                }

                
            }
            connection.Close();
        }

        DateTime start_time = new DateTime();
        DateTime end_time = new DateTime();

        //start uploading mindwave data into database
        private void button_save_Click(object sender, EventArgs e)
        {
            start_time = DateTime.Now;
            
            save_data = true;
            label_mw_save.Visible = true;
            button_save.BackColor = Color.Green;
            button_stop.BackColor = Color.Gray;
            label_mw_con.Invoke(new UpdateLabel(this.UpdateLabel_mw_con));

            StreamWriter file4 = new StreamWriter(directory + textBox_filename.Text + "_" + fase + "_WAVES" + ".txt", true);
            file4.WriteLine("NEW ACQUISITION: attention,meditationalfa1,alfa2,beta1,beta2,gamma1,gamma2,delta,theta,dataquality(0 = ok),datastamp");
            file4.Close();
            StreamWriter file5 = new StreamWriter(directory + textBox_filename.Text + "_" + fase + "_EEG" + ".txt", true);
            file5.WriteLine("NEW ACQUISITION: eeg_rawdata, timestamp");
            file5.Close();

            second = false;
        }

        //unused stop button
        private void button_STOP_Click(object sender, EventArgs e)
        {
            save_data = false;
            label_mw_save.Visible = false;
            button_stop.BackColor = Color.Red;
            button_save.BackColor = Color.Gray;
            end_time = DateTime.Now;
            
        }

        //initialize mindwave connection
        private void button_mw_Click(object sender, EventArgs e)
        {
            panel_eeg.Visible = true;
            panel_ecg.Visible = false;
            //panel_gsr.Visible = false;
            //panel_empatica.Visible = false;
            SerialPort sp = new SerialPort();
            sp.PortName = "COM9";
            sp.BaudRate = 9600;
            sp.Parity = Parity.None;
            sp.DataBits = 8;
            sp.StopBits = StopBits.One;
            sp.Handshake = Handshake.RequestToSend;
            sp.DtrEnable = true;
            sp.RtsEnable = true;

            try
            {
                sp.Open();
                string test;
                labelGsr.Text = (DateTime.Today.AddDays(1) - DateTime.Now).ToString(@"hh\:mm\:ss");
                var timer = new System.Windows.Forms.Timer { Interval = 1000 };
                timer.Tick += (o, args) =>
                {
                    labelGsr.Text = sp.ReadExisting();
                    test = sp.ReadExisting().ToString();
                };
                timer.Start();

            } catch
            {
                Console.WriteLine("serial port error");
            }


            //Console.WriteLine(sp.ReadExisting());





        }
        
        //unused start button
        private void button_start_Click(object sender, EventArgs e)
        {
            

            if (textBox_filename.Text != "")
            {
                Invoke(new UpdateLabel(this.UpdateLabel_vis));
                label_noname.Visible = false;
                save_data = true;

                StreamWriter file4 = new StreamWriter(directory + textBox_filename.Text + "_" + fase + "_ECG" + ".txt", true);
                file4.WriteLine("NEW ACQUISITION: attention,meditationalfa1,alfa2,beta1,beta2,gamma1,gamma2,delta,theta,dataquality(0 = ok),datastamp");
                file4.Close();
                StreamWriter file5 = new StreamWriter(directory + textBox_filename.Text + "_" + fase + "_RR" + ".txt", true);
                file5.WriteLine("NEW ACQUISITION: eeg_rawdata, timestamp");
                file5.Close();
                StreamWriter file6 = new StreamWriter(directory + textBox_filename.Text + "_" + fase + "_GENERAL_ECG" + ".txt", true);
                file6.WriteLine("NEW ACQUISITION: HR,Posture,RespirationRate,timestamp");
                file6.Close();

                StreamWriter file7 = new StreamWriter(directory + textBox_filename.Text + "_" + fase + "_WAVES" + ".txt", true);
                file7.WriteLine("NEW ACQUISITION: attention,meditationalfa1,alfa2,beta1,beta2,gamma1,gamma2,delta,theta,dataquality(0 = ok),datastamp");
                file7.Close();
                StreamWriter file8 = new StreamWriter(directory + textBox_filename.Text + "_" + fase + "_EEG" + ".txt", true);
                file8.WriteLine("NEW ACQUISITION: eeg_rawdata, timestamp");
                file8.Close();
            }
            else
            {
                label_noname.Visible = true;
            }
        }
        
        string logFilePath;
        string time;
        string bioharness_hr;
        string bioharness_br;
        string bioharness_hramp;
        string bioharness_bramp;
        string bioharness_activity;

        //Edit subject info in database
        private void button17_Click(object sender, EventArgs e)
        {
            string name;
            string gender;
            int age;
            string skill_lvl;

            //read subject info from textboxes
            if (textBoxName.Text == "")
            {
                name = "Test Subject";
            }
            else name = textBoxName.Text;

            if (textBoxGender.Text == "")
            {
                gender = "male";
            }
            else gender = textBoxGender.Text;

            if (textBoxAge.Text == "")
            {
                age = 28;
            }
            else age = Convert.ToInt32(textBoxAge.Text);

            if (textBoxSkill.Text == "")
            {
                skill_lvl = "average";
            }
            else skill_lvl = textBoxSkill.Text;

            string connectionString = "Server=localhost; Port=3306; Database=testdb; Uid=root; password=password;";
            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlCommand command = connection.CreateCommand();
            connection.Open();

            // insert data into local database
            command.CommandText = "UPDATE testdb.test SET subject_name = @name, gender = @gender, age = @age, skill_lvl = @skill_lvl WHERE timedate BETWEEN @start_time AND @end_time";

            command.Parameters.Clear();
            command.Parameters.AddWithValue("@name", name);
            command.Parameters.AddWithValue("@gender", gender);
            command.Parameters.AddWithValue("@age", age);
            command.Parameters.AddWithValue("@skill_lvl", skill_lvl);
            command.Parameters.AddWithValue("@start_time", (datebox1.Text + " " + time1box.Text));
            command.Parameters.AddWithValue("@end_time", (datebox2.Text + " " + time2box.Text));

            command.ExecuteNonQuery();
            connection.Close();
        }


        //Open connection and insert data from bioharness sensor (and info about subject) into database
        private void parse_bioharness_log(object sender, EventArgs e)
        {
            string name;
            string gender;
            int age;
            string skill_lvl;

            //read subject info from textboxes
            if (textBoxName.Text == "")
            {
                name = "Test Subject";
            }
            else name = textBoxName.Text;

            if (textBoxGender.Text == "")
            {
                gender = "male";
            }
            else gender = textBoxGender.Text;

            if (textBoxAge.Text == "")
            {
                age = 28;
            }
            else age = Convert.ToInt32(textBoxAge.Text);

            if (textBoxSkill.Text == "")
            {
                skill_lvl = "average";
            }
            else skill_lvl = textBoxSkill.Text;
            
            var directory = new DirectoryInfo(@"C:\\Users\\rhymak\\Documents\\BioHarness Test Logs");
            var myDirectory = (from f in directory.GetDirectories()
                          orderby f.LastWriteTime descending
                          select f).First();
            var path = Path.Combine(@"C:\\Users\\rhymak\\Documents\\BioHarness Test Logs", myDirectory.ToString());
            FileInfo[] filesInDir = myDirectory.GetFiles("Summary Data" + "*");
            foreach (FileInfo foundFile in filesInDir)
            {
                logFilePath = foundFile.FullName;
            }
            Console.WriteLine(logFilePath);

            string connectionString = "Server=localhost; Port=3306; Database=testdb; Uid=root; password=password;";
            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlCommand command = connection.CreateCommand();
            connection.Open();

            // insert data into local database
            command.CommandText = "UPDATE testdb.test SET subject_name = @name, gender = @gender, age = @age, skill_lvl = @skill_lvl, bioharness_hr=@bioharness_hr, bioharness_br=@bioharness_br, bioharness_hramp=@bioharness_hramp, bioharness_bramp=@bioharness_bramp, bioharness_activity=@bioharness_activity WHERE timedate=@time";

            String line = String.Empty;
            System.IO.StreamReader file = new System.IO.StreamReader(logFilePath);
            file.ReadLine();
            while ((line = file.ReadLine()) != null)
            {

                String[] parts_of_line = line.Split(',');
                for (int i = 0; i < parts_of_line.Length; i++)
                {
                    parts_of_line[i] = parts_of_line[i].Trim();
                }

                int miliseconds = Int32.Parse(parts_of_line[4]);
                parts_of_line[4] = parts_of_line[1] + '-' + parts_of_line[2] + '-' + parts_of_line[3] + ' ' + TimeSpan.FromMilliseconds(miliseconds).ToString();

                time = parts_of_line[4].Substring(0, 19);
                bioharness_hr = parts_of_line[6];
                bioharness_br = parts_of_line[7];
                bioharness_activity = parts_of_line[10];
                bioharness_bramp = parts_of_line[14];
                bioharness_hramp = parts_of_line[17];
                

                command.Parameters.Clear();
                command.Parameters.AddWithValue("@time", time);
                command.Parameters.AddWithValue("@bioharness_hr", bioharness_hr);
                command.Parameters.AddWithValue("@bioharness_br", bioharness_br);
                command.Parameters.AddWithValue("@bioharness_hramp", bioharness_hramp);
                command.Parameters.AddWithValue("@bioharness_bramp", bioharness_bramp);
                command.Parameters.AddWithValue("@bioharness_activity", bioharness_activity);
                command.Parameters.AddWithValue("@name", name);
                command.Parameters.AddWithValue("@gender", gender);
                command.Parameters.AddWithValue("@age", age);
                command.Parameters.AddWithValue("@skill_lvl", skill_lvl);
                                
                command.ExecuteNonQuery();
            }
            connection.Close();
        }
        
        DateTime gsr_time;
        string conductance;
        string resistance;
        
        //Parse data from GSR log (last edited text file in "arduino_logs" folder). Inserts data into database.
        private void parse_gsr_log(object sender, EventArgs e)
        {
            string connectionString = "Server=localhost; Port=3306; Database=testdb; Uid=root; password=password;";
            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlCommand command = connection.CreateCommand();
            MySqlCommand commandFixNulls = connection.CreateCommand();

            connection.Open();
            command.CommandText = "UPDATE testdb.test SET gsr_conductance = @conductance, gsr_resistance = @resistance WHERE timedate=@gsr_time";
            commandFixNulls.CommandText = "UPDATE testdb.test AS t1 SET " +
                "gsr_resistance = (SELECT gsr_resistance FROM (SELECT * FROM testdb.test) AS t2 WHERE t2.id = t1.id-1), " +
                "gsr_conductance = (SELECT gsr_conductance FROM(SELECT* FROM testdb.test) AS t2 WHERE t2.id = t1.id - 1) " +
                "WHERE gsr_resistance IS NULL";



            var directory = new DirectoryInfo(@"C:\\Users\\rhymak\\Documents\\Arduino Logs\\arduino_logs");
            var myfile = (from f in directory.GetFiles()
                          orderby f.LastWriteTime descending
                          select f).First();

            var path = Path.Combine(@"C:\\Users\\rhymak\\Documents\\Arduino Logs\\arduino_logs", myfile.ToString());

            String tempConductance = null;
            String tempResistance = null;

            String line = String.Empty;
            System.IO.StreamReader file = new System.IO.StreamReader(path);
            file.ReadLine();
            Console.WriteLine("filename: " + path.ToString());
            while ((line = file.ReadLine()) != null)
            {
                String[] parts_of_line = line.Split('\n');
                for (int i = 0; i < parts_of_line.Length; i++)
                {
                    parts_of_line[i] = parts_of_line[i].Trim();
                    String[] gsr = parts_of_line[i].Split(',');
                    gsr[0] = gsr[0].TrimEnd();
                    
                    try
                    {
                        gsr_time = DateTime.Parse(gsr[0]);
                        
                        if ((gsr[1].Length != 4) || (gsr[2].Length != 4))
                        {
                            gsr[0] = gsr[0].TrimEnd();
                            String[] gsr2 = parts_of_line[i-1].Split(',');
                            conductance = gsr2[1];
                            resistance = gsr2[2];
                        }
                        else
                        {
                            conductance = gsr[1];
                            tempConductance = gsr[1];
                            resistance = gsr[2];
                            tempResistance = gsr[2];
                        }
                    }
                    catch
                    {
                        gsr[0] = gsr[0].TrimEnd();
                        conductance = tempConductance;
                        resistance = tempResistance;
                    }
                }

                command.Parameters.Clear();
                command.Parameters.AddWithValue("@gsr_time", gsr_time.ToString("yyyy-MM-dd HH:mm:ss"));
                command.Parameters.AddWithValue("@conductance", conductance);
                command.Parameters.AddWithValue("@resistance", resistance);
                //commandFixNulls.Parameters.Clear();
                //commandFixNulls.Parameters.AddWithValue("@gsr_time", gsr_time.ToString("yyyy-MM-dd HH:mm:ss"));
                Console.WriteLine("time: " + gsr_time.ToString("yyyy-MM-dd HH:mm:ss"));
                command.ExecuteNonQuery();
                
            }
            commandFixNulls.ExecuteNonQuery();
            connection.Close();
        }

        

        
        // buttons for drawing charts from database (start, end time+date are taken from datebox1,2 and timebox1,2)
        private void draw_attention_chart(object sender, EventArgs e)
        {
            List<string> attentionChartData = new List<string>();

            Console.WriteLine("Start time: " + datebox1.Text + " " + time1box.Text);
            Console.WriteLine("End time: " + datebox2.Text + " " + time2box.Text);
            string connectionString = "Server=localhost; Port=3306; Database=testdb; Uid=root; password=password;";

            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = @"SELECT mindwave_attention FROM testdb.test WHERE timedate BETWEEN @start_time AND @end_time";
            //command.CommandText = @"SELECT bioharness_hr      FROM testdb.test WHERE subject_name='Martin Certicky'";

            connection.Open();
            command.Parameters.Clear();
            /*start_time = Convert.ToDateTime("2017-12-07 12:28:39");
            end_time = Convert.ToDateTime("2017-12-07 13:04:00");
            command.Parameters.AddWithValue("@start_time", start_time);
            command.Parameters.AddWithValue("@end_time", end_time);*/
            command.Parameters.AddWithValue("@start_time", (datebox1.Text + " " + time1box.Text));
            command.Parameters.AddWithValue("@end_time", (datebox2.Text + " " + time2box.Text));

            DataTable dt = new DataTable();
            using (connection)
            {
                using (command)
                {

                    using (MySqlDataReader dr = command.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            attentionChartData.Add(dr.GetValue(0).ToString());
                        }
                        dt.Load(dr);

                    }
                }
            }
            connection.Close();

            chart1.Series[0].Points.DataBindY(attentionChartData);
            chart1.Series[0]["SeriesLabelStyle"] = "Disabled";
            chart1.ChartAreas[0].AxisX.MajorGrid.LineWidth = 0;
            chart1.ChartAreas[0].AxisY.MajorGrid.LineWidth = 0;
            chart1.ChartAreas[0].AxisX.Title = "Time (seconds)";
            chart1.ChartAreas[0].AxisY.Title = "Attention (%)";
            chart1.ChartAreas[0].AxisY.Maximum = 100;
        }

        private void draw_meditation_chart(object sender, EventArgs e)
        {
            List<string> meditationChartData = new List<string>();



            
            string connectionString = "Server=localhost; Port=3306; Database=testdb; Uid=root; password=password;";

            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = @"SELECT mindwave_meditation FROM testdb.test WHERE timedate BETWEEN @start_time AND @end_time";
            //command.CommandText = @"SELECT bioharness_hr      FROM testdb.test WHERE subject_name='Martin Certicky'";

            connection.Open();
            command.Parameters.Clear();
            /*start_time = Convert.ToDateTime("2017-12-07 12:28:39");
            end_time = Convert.ToDateTime("2017-12-07 13:04:00");
            command.Parameters.AddWithValue("@start_time", start_time);
            command.Parameters.AddWithValue("@end_time", end_time);*/
            command.Parameters.AddWithValue("@start_time", (datebox1.Text + " " + time1box.Text));
            command.Parameters.AddWithValue("@end_time", (datebox2.Text + " " + time2box.Text));

            DataTable dt = new DataTable();
            using (connection)
            {
                using (command)
                {

                    using (MySqlDataReader dr = command.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            meditationChartData.Add(dr.GetValue(0).ToString());
                        }
                        dt.Load(dr);

                    }
                }
            }
            connection.Close();




            chart2.Series[0].Points.DataBindY(meditationChartData);
            chart2.Series[0]["SeriesLabelStyle"] = "Disabled";
            chart2.ChartAreas[0].AxisX.MajorGrid.LineWidth = 0;
            chart2.ChartAreas[0].AxisY.MajorGrid.LineWidth = 0;
            chart2.ChartAreas[0].AxisX.Title = "Time (seconds)";
            chart2.ChartAreas[0].AxisY.Title = "Meditation (%)";
            chart2.ChartAreas[0].AxisY.Maximum = 100;
        }

        private void draw_blink_frequency_chart(object sender, EventArgs e)
        {
            List<string> blinkingChartData = new List<string>();

            
            string connectionString = "Server=localhost; Port=3306; Database=testdb; Uid=root; password=password;";

            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = @"SELECT mindwave_blink_frequency FROM testdb.test WHERE timedate BETWEEN @start_time AND @end_time";
            //command.CommandText = @"SELECT bioharness_hr      FROM testdb.test WHERE subject_name='Martin Certicky'";

            connection.Open();
            command.Parameters.Clear();
            /*start_time = Convert.ToDateTime("2017-12-07 12:28:39");
            end_time = Convert.ToDateTime("2017-12-07 13:04:00");
            command.Parameters.AddWithValue("@start_time", start_time);
            command.Parameters.AddWithValue("@end_time", end_time);*/
            command.Parameters.AddWithValue("@start_time", (datebox1.Text + " " + time1box.Text));
            command.Parameters.AddWithValue("@end_time", (datebox2.Text + " " + time2box.Text));

            DataTable dt = new DataTable();
            using (connection)
            {
                using (command)
                {

                    using (MySqlDataReader dr = command.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            blinkingChartData.Add(dr.GetValue(0).ToString());
                        }
                        dt.Load(dr);

                    }
                }
            }
            connection.Close();


            chart3.Series[0].Points.DataBindY(blinkingChartData);
            chart3.Series[0]["SeriesLabelStyle"] = "Disabled";
            chart3.ChartAreas[0].AxisX.MajorGrid.LineWidth = 0;
            chart3.ChartAreas[0].AxisY.MajorGrid.LineWidth = 0;
            chart3.ChartAreas[0].AxisX.Title = "Time (seconds)";
            chart3.ChartAreas[0].AxisY.Title = "Number of blinks";
            chart3.ChartAreas[0].AxisY.Maximum = 50;
        }

        private void draw_gsr_conductance_chart(object sender, EventArgs e)
        {
            List<string> conductanceChartData = new List<string>();

            Console.WriteLine("Start time: " + datebox1.Text + " " + time1box.Text);
            Console.WriteLine("End time: " + datebox2.Text + " " + time2box.Text);
            string connectionString = "Server=localhost; Port=3306; Database=testdb; Uid=root; password=password;";

            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = @"SELECT gsr_conductance FROM testdb.test WHERE timedate BETWEEN @start_time AND @end_time";
            
            connection.Open();
            command.Parameters.Clear();
            /*start_time = Convert.ToDateTime("2017-12-07 12:28:39");
            end_time = Convert.ToDateTime("2017-12-07 13:04:00");
            command.Parameters.AddWithValue("@start_time", start_time);
            command.Parameters.AddWithValue("@end_time", end_time);*/
            command.Parameters.AddWithValue("@start_time", (datebox1.Text + " " + time1box.Text));
            command.Parameters.AddWithValue("@end_time", (datebox2.Text + " " + time2box.Text));

            DataTable dt = new DataTable();
            using (connection)
            {
                using (command)
                {

                    using (MySqlDataReader dr = command.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            conductanceChartData.Add(dr.GetValue(0).ToString());
                        }
                        dt.Load(dr);

                    }
                }
            }
            connection.Close();


            chart4.Series[0].Points.DataBindY(conductanceChartData);
            chart4.Series[0]["SeriesLabelStyle"] = "Disabled";
            //chart4.ChartAreas[0].AxisX.LabelStyle.Format = "mm:ss";
            chart4.ChartAreas[0].AxisX.MajorGrid.LineWidth = 0;
            chart4.ChartAreas[0].AxisY.MajorGrid.LineWidth = 0;
            chart4.ChartAreas[0].AxisX.Title = "Time (seconds)";
            chart4.ChartAreas[0].AxisY.Title = "GSR Conductance";
            //chart4.ChartAreas[0].AxisY.Maximum = 100;
        }

        private void draw_gsr_resistance_chart(object sender, EventArgs e)
        {
            List<string> resistanceChartData = new List<string>();

            
            string connectionString = "Server=localhost; Port=3306; Database=testdb; Uid=root; password=password;";

            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = @"SELECT gsr_resistance FROM testdb.test WHERE timedate BETWEEN @start_time AND @end_time";

            connection.Open();
            command.Parameters.Clear();
            /*start_time = Convert.ToDateTime("2017-12-07 12:28:39");
            end_time = Convert.ToDateTime("2017-12-07 13:04:00");
            command.Parameters.AddWithValue("@start_time", start_time);
            command.Parameters.AddWithValue("@end_time", end_time);*/
            command.Parameters.AddWithValue("@start_time", (datebox1.Text + " " + time1box.Text));
            command.Parameters.AddWithValue("@end_time", (datebox2.Text + " " + time2box.Text));

            DataTable dt = new DataTable();
            using (connection)
            {
                using (command)
                {

                    using (MySqlDataReader dr = command.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            resistanceChartData.Add(dr.GetValue(0).ToString());
                        }
                        dt.Load(dr);

                    }
                }
            }
            connection.Close();


            chart5.Series[0].Points.DataBindY(resistanceChartData);
            chart5.Series[0]["SeriesLabelStyle"] = "Disabled";
            chart5.ChartAreas[0].AxisX.MajorGrid.LineWidth = 0;
            chart5.ChartAreas[0].AxisY.MajorGrid.LineWidth = 0;
            chart5.ChartAreas[0].AxisX.Title = "Time (seconds)";
            chart5.ChartAreas[0].AxisY.Title = "GSR Resistance";
            //chart5.ChartAreas[0].AxisY.Maximum = 100;
        }

        private void draw_hr_chart(object sender, EventArgs e)
        {
            List<string> bh_hrChartData = new List<string>();

            Console.WriteLine("start time: " + start_time.ToString("Start time:" + datebox1.Text + " " + time1box.Text));
            Console.WriteLine("end time: " + end_time.ToString("End time:" + datebox2.Text + " " + time2box.Text));
            string connectionString = "Server=localhost; Port=3306; Database=testdb; Uid=root; password=password;";

            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = @"SELECT bioharness_hr FROM testdb.test WHERE timedate BETWEEN @start_time AND @end_time";

            connection.Open();
            command.Parameters.Clear();
            /*start_time = Convert.ToDateTime("2017-12-07 12:28:39");
            end_time = Convert.ToDateTime("2017-12-07 13:04:00");
            command.Parameters.AddWithValue("@start_time", start_time);
            command.Parameters.AddWithValue("@end_time", end_time);*/
            command.Parameters.AddWithValue("@start_time", (datebox1.Text + " " + time1box.Text));
            command.Parameters.AddWithValue("@end_time", (datebox2.Text + " " + time2box.Text));

            DataTable dt = new DataTable();
            using (connection)
            {
                using (command)
                {

                    using (MySqlDataReader dr = command.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            bh_hrChartData.Add(dr.GetValue(0).ToString());
                        }
                        dt.Load(dr);

                    }
                }
            }
            connection.Close();



            
            chart6.Series[0].Points.DataBindY(bh_hrChartData);
            chart6.Series[0]["SeriesLabelStyle"] = "Disabled";
            chart6.ChartAreas[0].AxisX.MajorGrid.LineWidth = 0;
            chart6.ChartAreas[0].AxisY.MajorGrid.LineWidth = 0;
            chart6.ChartAreas[0].AxisX.Title = "Time (seconds)";
            chart6.ChartAreas[0].AxisY.Title = "Heart Rate";
            //chart6.ChartAreas[0].AxisY.Maximum = 100;
            
        }

        private void draw_hramp_chart(object sender, EventArgs e)
        {
            List<string> bh_hrampChartData = new List<string>();

            
            string connectionString = "Server=localhost; Port=3306; Database=testdb; Uid=root; password=password;";

            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = @"SELECT bioharness_hramp FROM testdb.test WHERE timedate BETWEEN @start_time AND @end_time";

            connection.Open();
            command.Parameters.Clear();
            /*start_time = Convert.ToDateTime("2017-12-07 12:28:39");
            end_time = Convert.ToDateTime("2017-12-07 13:04:00");
            command.Parameters.AddWithValue("@start_time", start_time);
            command.Parameters.AddWithValue("@end_time", end_time);*/
            command.Parameters.AddWithValue("@start_time", (datebox1.Text + " " + time1box.Text));
            command.Parameters.AddWithValue("@end_time", (datebox2.Text + " " + time2box.Text));

            DataTable dt = new DataTable();
            using (connection)
            {
                using (command)
                {

                    using (MySqlDataReader dr = command.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            bh_hrampChartData.Add(dr.GetValue(0).ToString());
                        }
                        dt.Load(dr);

                    }
                }
            }
            connection.Close();




            chart7.Series[0].Points.DataBindY(bh_hrampChartData);
            chart7.Series[0]["SeriesLabelStyle"] = "Disabled";
            chart7.ChartAreas[0].AxisX.MajorGrid.LineWidth = 0;
            chart7.ChartAreas[0].AxisY.MajorGrid.LineWidth = 0;
            chart7.ChartAreas[0].AxisX.Title = "Time (seconds)";
            chart7.ChartAreas[0].AxisY.Title = "Heart Rate Amplitude";
            //chart7.ChartAreas[0].AxisY.Maximum = 100;
        }

        private void draw_activity_chart(object sender, EventArgs e)
        {
            List<string> bh_activityChartData = new List<string>();

            
            string connectionString = "Server=localhost; Port=3306; Database=testdb; Uid=root; password=password;";

            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = @"SELECT bioharness_activity FROM testdb.test WHERE timedate BETWEEN @start_time AND @end_time";

            connection.Open();
            command.Parameters.Clear();
            /*start_time = Convert.ToDateTime("2017-12-07 12:28:39");
            end_time = Convert.ToDateTime("2017-12-07 13:04:00");
            command.Parameters.AddWithValue("@start_time", start_time);
            command.Parameters.AddWithValue("@end_time", end_time);*/
            command.Parameters.AddWithValue("@start_time", (datebox1.Text + " " + time1box.Text));
            command.Parameters.AddWithValue("@end_time", (datebox2.Text + " " + time2box.Text));

            DataTable dt = new DataTable();
            using (connection)
            {
                using (command)
                {

                    using (MySqlDataReader dr = command.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            bh_activityChartData.Add(dr.GetValue(0).ToString());
                        }
                        dt.Load(dr);

                    }
                }
            }
            connection.Close();




            chart8.Series[0].Points.DataBindY(bh_activityChartData);
            chart8.Series[0]["SeriesLabelStyle"] = "Disabled";
            chart8.ChartAreas[0].AxisX.MajorGrid.LineWidth = 0;
            chart8.ChartAreas[0].AxisY.MajorGrid.LineWidth = 0;
            chart8.ChartAreas[0].AxisX.Title = "Time (seconds)";
            chart8.ChartAreas[0].AxisY.Title = "Activity";
            //chart8.ChartAreas[0].AxisY.Maximum = 100;
        }

        private void draw_br_chart(object sender, EventArgs e)
        {
            List<string> bh_brChartData = new List<string>();

            
            string connectionString = "Server=localhost; Port=3306; Database=testdb; Uid=root; password=password;";

            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = @"SELECT bioharness_br FROM testdb.test WHERE timedate BETWEEN @start_time AND @end_time";

            connection.Open();
            command.Parameters.Clear();
            /*start_time = Convert.ToDateTime("2017-12-07 12:28:39");
            end_time = Convert.ToDateTime("2017-12-07 13:04:00");
            command.Parameters.AddWithValue("@start_time", start_time);
            command.Parameters.AddWithValue("@end_time", end_time);*/
            command.Parameters.AddWithValue("@start_time", (datebox1.Text + " " + time1box.Text));
            command.Parameters.AddWithValue("@end_time", (datebox2.Text + " " + time2box.Text));

            DataTable dt = new DataTable();
            using (connection)
            {
                using (command)
                {

                    using (MySqlDataReader dr = command.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            bh_brChartData.Add(dr.GetValue(0).ToString());
                        }
                        dt.Load(dr);

                    }
                }
            }
            connection.Close();




            chart9.Series[0].Points.DataBindY(bh_brChartData);
            chart9.Series[0]["SeriesLabelStyle"] = "Disabled";
            chart9.ChartAreas[0].AxisX.MajorGrid.LineWidth = 0;
            chart9.ChartAreas[0].AxisY.MajorGrid.LineWidth = 0;
            chart9.ChartAreas[0].AxisX.Title = "Time (seconds)";
            chart9.ChartAreas[0].AxisY.Title = "Breathing Rate";
            //chart9.ChartAreas[0].AxisY.Maximum = 100;
        }

        private void draw_bramp_chart(object sender, EventArgs e)
        {
            List<string> bh_brampChartData = new List<string>();

            
            string connectionString = "Server=localhost; Port=3306; Database=testdb; Uid=root; password=password;";

            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = @"SELECT bioharness_bramp FROM testdb.test WHERE timedate BETWEEN @start_time AND @end_time";

            connection.Open();
            command.Parameters.Clear();
            /*start_time = Convert.ToDateTime("2017-12-07 12:28:39");
            end_time = Convert.ToDateTime("2017-12-07 13:04:00");
            command.Parameters.AddWithValue("@start_time", start_time);
            command.Parameters.AddWithValue("@end_time", end_time);*/
            command.Parameters.AddWithValue("@start_time", (datebox1.Text + " " + time1box.Text));
            command.Parameters.AddWithValue("@end_time", (datebox2.Text + " " + time2box.Text));

            DataTable dt = new DataTable();
            using (connection)
            {
                using (command)
                {

                    using (MySqlDataReader dr = command.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            bh_brampChartData.Add(dr.GetValue(0).ToString());
                        }
                        dt.Load(dr);

                    }
                }
            }
            connection.Close();




            chart10.Series[0].Points.DataBindY(bh_brampChartData);
            chart10.Series[0]["SeriesLabelStyle"] = "Disabled";
            chart10.ChartAreas[0].AxisX.MajorGrid.LineWidth = 0;
            chart10.ChartAreas[0].AxisY.MajorGrid.LineWidth = 0;
            chart10.ChartAreas[0].AxisX.Title = "Time (seconds)";
            chart10.ChartAreas[0].AxisY.Title = "Breathing Rate Amplitude";
            //chart10.ChartAreas[0].AxisY.Maximum = 100;
        }

       
        

        // buttons for showing/hiding individual sets of charts (sorted by sensor)
        // show/hide mindwave charts
        private void show_mindwave_charts(object sender, EventArgs e)
        {
            
            button2.Visible = true;
            button3.Visible = true;
            button4.Visible = true;

            button6.Visible = false;
            button8.Visible = false;

            button9.Visible = false;
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            button16.Visible = false;

            chart1.Visible = true;
            chart2.Visible = true;
            chart3.Visible = true;
            chart5.Visible = false;
            chart4.Visible = false;
            chart6.Visible = false;
            chart7.Visible = false;
            chart8.Visible = false;
            chart9.Visible = false;
            chart10.Visible = false;
            chart11.Visible = false;

            button2.PerformClick();
            button3.PerformClick();
            button4.PerformClick();
        }

        // show/hide GSR charts
        private void show_gst_charts(object sender, EventArgs e)
        {
            button2.Visible = false;
            button3.Visible = false;
            button4.Visible = false;

            button6.Visible = true;
            button8.Visible = true;

            button9.Visible = false;
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            button16.Visible = false;

            chart1.Visible = false;
            chart2.Visible = false;
            chart3.Visible = false;
            chart5.Visible = true;
            chart4.Visible = true;
            chart6.Visible = false;
            chart7.Visible = false;
            chart8.Visible = false;
            chart9.Visible = false;
            chart10.Visible = false;
            chart11.Visible = false;

            button6.PerformClick();
            button8.PerformClick();
        }

        // show/hide Bioharness charts
        private void show_bioharness_charts(object sender, EventArgs e)
        {
            button2.Visible = false;
            button3.Visible = false;
            button4.Visible = false;

            button6.Visible = false;
            button8.Visible = false;

            button9.Visible = true;
            button11.Visible = true;
            button12.Visible = true;
            button13.Visible = true;
            button14.Visible = true;
            button16.Visible = false;

            chart1.Visible = false;
            chart2.Visible = false;
            chart3.Visible = false;
            chart4.Visible = false;
            chart5.Visible = false;
            chart6.Visible = true;
            chart7.Visible = true;
            chart8.Visible = true;
            chart9.Visible = true;
            chart10.Visible = true;
            chart11.Visible = false;

            button9.PerformClick();
            button11.PerformClick();
            button12.PerformClick();
            button13.PerformClick();
            button14.PerformClick();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            button3.Visible = false;
            button4.Visible = false;

            button6.Visible = false;
            button8.Visible = false;

            button9.Visible = false;
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            button16.Visible = true;

            chart1.Visible = false;
            chart2.Visible = false;
            chart3.Visible = false;
            chart4.Visible = false;
            chart5.Visible = false;
            chart6.Visible = false;
            chart7.Visible = false;
            chart8.Visible = false;
            chart9.Visible = false;
            chart10.Visible = false;
            chart11.Visible = true;

            button16.PerformClick();
        }

        //set last experiment's date and time into date and time boxes
        private void button18_Click(object sender, EventArgs e)
        {
            var directory = new DirectoryInfo(@"C:\\Users\\rhymak\\Documents\\BioHarness Test Logs");
            var myDirectory = (from f in directory.GetDirectories()
                               orderby f.LastWriteTime descending
                               select f).First();
            
            var path = Path.Combine(@"C:\\Users\\rhymak\\Documents\\BioHarness Test Logs", myDirectory.ToString());
            FileInfo[] filesInDir = myDirectory.GetFiles("Summary Data" + "*");
            foreach (FileInfo foundFile in filesInDir)
            {
                logFilePath = foundFile.FullName;
            }
            
            
            String line = String.Empty;
            System.IO.StreamReader file = new System.IO.StreamReader(logFilePath);
            file.ReadLine();

            var lines = File.ReadLines(logFilePath);
            file.ReadLine();
            string firstLine = file.ReadLine();
            string lastLine = lines.Last();
            

            String[] firsttemp = firstLine.Split(',');
            String[] lasttemp = lastLine.Split(',');
            for (int i = 0; i < firsttemp.Length; i++)
            {
                firsttemp[i] = firsttemp[i].Trim();
                lasttemp[i] = lasttemp[i].Trim();
            }
            int miliseconds_first = Int32.Parse(firsttemp[4]);
            int miliseconds_last = Int32.Parse(lasttemp[4]);


            firsttemp[4] = firsttemp[1] + '-' + firsttemp[2] + '-' + firsttemp[3] + ' ' + TimeSpan.FromMilliseconds(miliseconds_first).ToString();
            lasttemp[4] = lasttemp[1] + '-' + lasttemp[2] + '-' + lasttemp[3] + ' ' + TimeSpan.FromMilliseconds(miliseconds_last).ToString();
            
            string firstLine_time = firsttemp[4].Substring(0, 19);
            string lastLine_time = lasttemp[4].Substring(0, 19);

            datebox1.Text = firsttemp[1] + '-' + firsttemp[2] + '-' + firsttemp[3];
            datebox2.Text = lasttemp[1] + '-' + lasttemp[2] + '-' + lasttemp[3];

            time1box.Text = TimeSpan.FromMilliseconds(miliseconds_first).ToString().Substring(0, 8);
            time2box.Text = TimeSpan.FromMilliseconds(miliseconds_last).ToString().Substring(0, 8);
            
        }

        
    }
}
