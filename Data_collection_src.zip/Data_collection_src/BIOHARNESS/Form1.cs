﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace WindowsFormsApplication4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
             watcher.Changed += new FileSystemEventHandler(OnChanged);
             watcher.Created += new FileSystemEventHandler(OnChanged);
             watcher.Deleted += new FileSystemEventHandler(OnChanged);
        }

        int j = 0;
        int r = 0;
        int s = 0;
        DateTime tempo_iniziale;
        DateTime tempo_finale;
        DateTime tempo_iniziale_RR;
        DateTime tempo_finale_RR;
        DateTime tempo_iniziale_SU;
        DateTime tempo_finale_SU;
        string pathfile;
        string appoggio;
        string appoggio_RR;
        string appoggio_SU;
        string Path_relativo = Environment.CurrentDirectory;
        string line2 = "";

        public void OnChanged(object source, FileSystemEventArgs e)
        {
        // Specify what is done when a file is changed

            pathfile = e.FullPath;
                if (e.Name.Contains("ECG"))
                {
                    if (e.ChangeType.ToString() == "Created")
                    {
                        tempo_iniziale = DateTime.UtcNow;
                    }

                    if (e.ChangeType.ToString() == "Changed")
                    {
                        tempo_finale = DateTime.UtcNow;

                        TimeSpan dt = tempo_finale - tempo_iniziale;
                        TimeSpan camp = new TimeSpan(dt.Ticks / File.ReadAllLines(pathfile).Length - 3);
                        double ms = (double)camp.TotalMilliseconds;

                        StringBuilder newfile3 = new StringBuilder();
                        string[] file4 = File.ReadAllLines(pathfile);
                        foreach (string line in file4)
                        {
                            if (j >= 1)
                            {
                                appoggio = line + "," + tempo_iniziale.AddMilliseconds(ms * (j - 2)).Subtract(new DateTime(1970, 1, 1)).TotalMilliseconds.ToString();
                                StreamWriter file2 = new StreamWriter(Environment.CurrentDirectory + "/TEST_FASCIA/" + "ECG_" + textBox_nomefile.Text + ".txt", true);
                                file2.WriteLine(appoggio);
                                file2.Close();
                            }
                            j++;
                        }

                        StreamWriter file3 = new StreamWriter(Environment.CurrentDirectory + "/TEST_FASCIA/" + "ECG_" + textBox_nomefile.Text + ".txt", true);
                        file3.WriteLine("****************** t_camp: " + ms.ToString());
                        file3.Close();
                        j = 0;

                    }
                }

                if (e.Name.Contains("RtoR"))
                {
                    if (e.ChangeType.ToString() == "Created")
                    {
                        tempo_iniziale_RR = DateTime.UtcNow;
                    }

                    if (e.ChangeType.ToString() == "Changed")
                    {
                        tempo_finale_RR = DateTime.UtcNow;

                        TimeSpan dt = tempo_finale_RR - tempo_iniziale_RR;
                        TimeSpan camp = new TimeSpan(dt.Ticks / File.ReadAllLines(pathfile).Length - 3);
                        double ms = (double)camp.TotalMilliseconds;

                        StringBuilder newfile3 = new StringBuilder();
                        string[] file4 = File.ReadAllLines(pathfile);
                        foreach (string line in file4)
                        {
                            if (r >= 1)
                            {
                                appoggio_RR = line + "," + tempo_iniziale.AddMilliseconds(ms * (r - 2)).Subtract(new DateTime(1970, 1, 1)).TotalMilliseconds.ToString();
                                StreamWriter file2 = new StreamWriter(Environment.CurrentDirectory + "/TEST_FASCIA/" + "RR_" + textBox_nomefile.Text + ".txt", true);
                                file2.WriteLine(appoggio_RR);
                                file2.Close();
                            }
                            r++;
                        }

                        StreamWriter file3 = new StreamWriter(Environment.CurrentDirectory + "/TEST_FASCIA/" + "RR_" + textBox_nomefile.Text + ".txt", true);
                        file3.WriteLine("****************** t_camp: " + ms.ToString());
                        file3.Close();
                        r = 0;
                    }
                }

                if (e.Name.Contains("Sum"))
                {
                    if (e.ChangeType.ToString() == "Created")
                    {
                        tempo_iniziale_SU = DateTime.UtcNow;
                    }

                    if (e.ChangeType.ToString() == "Changed")
                    {
                        tempo_finale_SU = DateTime.UtcNow;

                        TimeSpan dt = tempo_finale_SU - tempo_iniziale_SU;
                        TimeSpan camp = new TimeSpan(dt.Ticks / File.ReadAllLines(pathfile).Length - 3);
                        double ms = (double)camp.TotalMilliseconds;

                        StringBuilder newfile3 = new StringBuilder();
                    // tu su data zo senzora
                        string[] file4 = File.ReadAllLines(pathfile);
                        foreach (string line in file4)
                        {
                            if (s >= 1)
                            {
                                appoggio_SU = line + "," + tempo_iniziale.AddMilliseconds(ms * (s - 2)).Subtract(new DateTime(1970, 1, 1)).TotalMilliseconds.ToString();
                                StreamWriter file2 = new StreamWriter(Environment.CurrentDirectory + "/TEST_FASCIA/" + "SUM_" + textBox_nomefile.Text + ".txt", true);
                                // tu sa zapisuju do textaku (bioharness/bin/debug/test_fascia)
                                file2.WriteLine(appoggio_SU);
                                file2.Close();
                            }
                            s++;
                        }

                        StreamWriter file3 = new StreamWriter(Environment.CurrentDirectory + "/TEST_FASCIA/" + "SUM_" + textBox_nomefile.Text + ".txt", true);
                        file3.WriteLine("****************** t_camp: " + ms.ToString());
                        file3.Close();
                        s = 0;
                    }
                }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StringBuilder newFile = new StringBuilder();
            string line = Path_relativo + "/BioHarness Bluetooth Test Application V2_2_1_0_10/BioHarness Bluetooth Test Application V2.exe";
            System.Diagnostics.Process.Start(line);
            line2 = File.ReadLines(Path_relativo + "/Path.txt").Skip(1).Take(1).First();
            watcher.Path = line2;
     //       System.Diagnostics.Process.Start("C:/Users/Stefano/Desktop/BioHarness Bluetooth SDK 9700.0019.v3b/Bluetooth Test Application/Application Files/BioHarness Bluetooth Test Application V2_2_1_0_10/BioHarness Bluetooth Test Application V2.exe");
        }

    }
}

